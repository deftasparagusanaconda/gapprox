from . import paramgens, structgens, regressor, outliers, plotters, parser, sampler
from .api import API as _API
api = _API()
